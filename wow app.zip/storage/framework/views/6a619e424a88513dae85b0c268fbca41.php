<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Dashboard</h3>
                    </div>
                    <div class="card-body">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique harum id suscipit esse
                            praesentium maiores eius! Laboriosam non, nisi sequi illo, neque similique necessitatibus animi
                            voluptas deserunt odit quas unde perspiciatis nulla nesciunt tenetur aliquid commodi incidunt
                            numquam, voluptatum laborum!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\default-structure\resources\views/dashboard.blade.php ENDPATH**/ ?>