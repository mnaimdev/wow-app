<?php

namespace App\Http\Controllers;

use App\Models\CustomerLogin;
use App\Models\User;
use App\Models\UserToken;
use App\services\GoogleService;
use App\services\UserService;
use Laravel\Socialite\Facades\Socialite;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class GoogleController extends Controller
{
    // public function googleRedirect()
    // {
    //     try {
    //         return Socialite::driver('google')->redirect();
    //     } catch (\Exception $e) {
    //         return response()->json(['message' => $e->getMessage()], 400);
    //     }
    // }


    // public function googleCallback()
    // {
    //     try {
    //         $user = Socialite::driver('google')->user();

    //         if (CustomerLogin::where('email', $user->getEmail())->exists()) {
    //             if (Auth::attempt(['email' => $user->getEmail(), 'password' => '1234'])) {
    //                 if (CustomerLogin::where('email', $user->getEmail())->where('status', 'ON')) {
    //                     return response()->json(['message' => 'Login Successful'], 200);
    //                 }
    //             }
    //         } else {
    //             CustomerLogin::insert([
    //                 'name' => $user->getName(),
    //                 'email' => $user->getEmail(),
    //                 'password' => bcrypt('1234'),
    //             ]);

    //             return response()->json(['message' => 'We have sent you a notification!Please check this for login'], 200);
    //             // if (Auth::attempt(['email' => $user->getEmail(), 'password' => '1234'])) {
    //             // }
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['message' => $e->getMessage()], 400);
    //     }
    // }


    public function googleLogin(Request $request)
    {
        try {
            $service = new GoogleService();
            $token = $service->setEmail($request->email)
                ->login();

            return response()->json(['message' => 'User Added Successfully', 'token'    => $token], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }


    public function loginToken(Request $request)
    {
        try {
            $service = new GoogleService();
            $result = $service->setToken($request->token)
                ->loginProcess();

            return response()->json(['message' => $result]);
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }



    public function profileUpdate(Request $request)
    {


        $service = new UserService();
        $result = $service->setName($request->name)
            ->setPhone($request->phone)
            ->setTelegramNumber($request->telegramNumber)
            ->profile($request->token);

        return response()->json(['message'  => $result], 200);
    }



    public function profileData($token)
    {
        try {
            if (UserToken::where('token', $token)->exists()) {
                $service = new UserService();
                $result = $service->profileData($token);

                return response()->json(['message' => $result], 200);
            } else {
                return response()->json(['message' => 'Invalid Token'], 400);
            }
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }


    public function deleteUser($token)
    {
        try {
            $service = new UserService();
            $service->deleteUser($token);

            return response()->json(['message' => 'User Deleted Successfully'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }
}
